// JavaScript Document

var x1 = activeDocument.selection.bounds[0];
var y1 = activeDocument.selection.bounds[1];
var x2 = activeDocument.selection.bounds[2];
var y2 = activeDocument.selection.bounds[3];

var tmp = x1.toString() + y1.toString() + x2.toString() + y2.toString();
var rect = tmp.split(' px');

prompt('areaタグのcoordsに使用できます。（座標の始点はスライスではなく、カンバスです。）', rect[0]+','+rect[1]+','+rect[2]+','+rect[3]);

